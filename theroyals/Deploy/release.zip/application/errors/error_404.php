<?
$domain='http://theroyals.lc/';
$inc="http://theroyals.lc/menu/errorPages/404/";
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
    <title>404 - Light Grey HTML + CSS template</title>
    <link href="<?=$inc?>style.css" rel="stylesheet" type="text/css" />
    <style type="text/css">
        body {
            margin-left: 0px;
            margin-top: 0px;
            margin-right: 0px;
            margin-bottom: 0px;
        }
    </style>
    <script type="text/javascript">
        function MM_swapImgRestore() { //v3.0
            var i,x,a=document.MM_sr; for(i=0;a&&i<a.length&&(x=a[i])&&x.oSrc;i++) x.src=x.oSrc;
        }
        function MM_preloadImages() { //v3.0
            var d=document; if(d.images){ if(!d.MM_p) d.MM_p=new Array();
                var i,j=d.MM_p.length,a=MM_preloadImages.arguments; for(i=0; i<a.length; i++)
                    if (a[i].indexOf("#")!=0){ d.MM_p[j]=new Image; d.MM_p[j++].src=a[i];}}
        }

        function MM_findObj(n, d) { //v4.01
            var p,i,x;  if(!d) d=document; if((p=n.indexOf("?"))>0&&parent.frames.length) {
                d=parent.frames[n.substring(p+1)].document; n=n.substring(0,p);}
            if(!(x=d[n])&&d.all) x=d.all[n]; for (i=0;!x&&i<d.forms.length;i++) x=d.forms[i][n];
            for(i=0;!x&&d.layers&&i<d.layers.length;i++) x=MM_findObj(n,d.layers[i].document);
            if(!x && d.getElementById) x=d.getElementById(n); return x;
        }

        function MM_swapImage() { //v3.0
            var i,j=0,x,a=MM_swapImage.arguments; document.MM_sr=new Array; for(i=0;i<(a.length-2);i+=3)
                if ((x=MM_findObj(a[i]))!=null){document.MM_sr[j++]=x; if(!x.oSrc) x.oSrc=x.src; x.src=a[i+2];}
        }
    </script>
</head>

<body onload="MM_preloadImages('<?=$inc?>images/searchhover.png','<?=$inc?>images/social-icons/twitter-hover.png','<?=$inc?>images/social-icons/envato-hover.png','images/social-icons/facebook-hover.png','images/social-icons/tumblr-hover.png')">

<div id="box">

    <div id="typebox">

        Lorem ipsum dolor sit amet, consectetur adipiscing elit. Nam sem elit, convallis sit amet aliquet id, tempor quis risus.

        <!--first navigation menu starts-->

        <div id="listone">

            <ul>

                <img src="<?=$inc?>images/break.png" />

                <li>
                    <img src="<?=$inc?>images/dot.png" /><a href="<?=$domain?>">Home Page</a>
                </li>

                <img src="<?=$inc?>images/break.png" />

                <li>
                    <img src="<?=$inc?>images/dot.png" /><a href="#">About Us</a>
                </li>

                <img src="<?=$inc?>images/break.png" />

                <li>
                    <img src="<?=$inc?>images/dot.png" /><a href="#">Portfolio</a>
                </li>

                <img src="<?=$inc?>images/break.png" />

                <li>
                    <img src="<?=$inc?>images/dot.png" /><a href="#">Blog</a>
                </li>

                <img src="<?=$inc?>images/break.png" />

                <li>
                    <img src="<?=$inc?>images/dot.png" /><a href="#">Get in Touch</a>
                </li>

                <img src="<?=$inc?>images/break.png" />

            </ul>

            <!--end of first navigation-->

            <!--second navigation menu starts-->

            <div id="listtwo">

                <ul>

                    <img src="<?=$inc?>images/break.png" />

                    <li>
                        <img src="<?=$inc?>images/dot.png" /><a href="#">Terms and Conditions</a>
                    </li>

                    <img src="<?=$inc?>images/break.png" />

                    <li>
                        <img src="<?=$inc?>images/dot.png" /><a href="#">Privacy Policy</a>
                    </li>

                    <img src="<?=$inc?>images/break.png" />

                    <li>
                        <img src="<?=$inc?>images/dot.png" /><a href="#">FAQ</a>
                    </li>

                    <img src="<?=$inc?>images/break.png" />

                    <li>
                        <img src="<?=$inc?>images/dot.png" /><a href="#">Testimonials</a>
                    </li>

                    <img src="<?=$inc?>images/break.png" />

                </ul>

            </div>

            <!--end of second navigation-->

            <!--search bar starts-->

            <div id="searchbar">

                <div id="searchbutton">

                    <a href="#" onmouseout="MM_swapImgRestore()" onmouseover="MM_swapImage('Image23','','<?=$inc?>images/searchhover.png',1)"><img src="<?=$inc?>images/searchbutton.png" name="Image23" width="45" height="11" border="0" id="Image23" /></a>

                </div><!--end of search button-->

            </div><!--end of search bar-->

        </div>

    </div>

</div>

<div id="socialbox"><!--start of social icons-->


    <div id="socialicon"><!--twitter-->

        <a href="#" onmouseout="MM_swapImgRestore()" onmouseover="MM_swapImage('twitter','','<?=$inc?>images/social-icons/twitter-hover.png',1)"><img src="<?=$inc?>images/social-icons/twitter.png" name="twitter" width="65" height="69" border="0" id="twitter" /></a>

    </div><!--end of twitter-->


    <div id="socialicon"><!--envato-->

        <a href="#" onmouseout="MM_swapImgRestore()" onmouseover="MM_swapImage('envato','','<?=$inc?>images/social-icons/envato-hover.png',1)"><img src="<?=$inc?>images/social-icons/envato.png" name="envato" width="65" height="69" border="0" id="envato" /></a>

    </div><!--end of envato-->


    <div id="socialicon"><!--facebook-->

        <a href="#" onmouseout="MM_swapImgRestore()" onmouseover="MM_swapImage('facebook','','<?=$inc?>images/social-icons/facebook-hover.png',1)"><img src="<?=$inc?>images/social-icons/facebook.png" name="facebook" width="65" height="69" border="0" id="facebook" /></a>

    </div><!--end of facebook-->

    <div id="socialicon"><!--tumblr-->

        <a href="#" onmouseout="MM_swapImgRestore()" onmouseover="MM_swapImage('tumblr','','<?=$inc?>images/social-icons/tumblr-hover.png',1)"><img src="<?=$inc?>images/social-icons/tumblr.png" name="tumblr" width="65" height="69" border="0" id="tumblr" /></a>

    </div><!--end of tumblr-->

</div><!--end of social icons-->

</body>
</html>