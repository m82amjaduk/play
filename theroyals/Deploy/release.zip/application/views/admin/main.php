<?php
/**
 * Created by PhpStorm.
 * User: amzad
 * Date: 24/06/14
 * Time: 19:17
 */?>

<? require_once $page.".php"?>